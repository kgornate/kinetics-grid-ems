"""Entry point for the i.MX93 EMS gateway backend."""

from pathlib import Path
import signal
import sys

CURRENT_FILE = Path(__file__).resolve()
IMX93_GATEWAY_DIR = CURRENT_FILE.parent
if str(IMX93_GATEWAY_DIR) not in sys.path:
    sys.path.insert(0, str(IMX93_GATEWAY_DIR))

from core.app import EMSGatewayApplication
from core.cli import parse_args


def main() -> None:
    args = parse_args()
    app = EMSGatewayApplication(args)

    if getattr(args, "print_runtime_config", False):
        import json

        print(json.dumps(app.runtime_config.to_safe_dict(), indent=2, sort_keys=True))
        return

    def handle_shutdown(signum, frame):
        app.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_shutdown)
    signal.signal(signal.SIGTERM, handle_shutdown)

    try:
        app.start()
        app.run_forever()
    except KeyboardInterrupt:
        app.stop()
    except Exception as error:
        print(f"[MAIN] Fatal error: {error}")
        app.stop()
        sys.exit(1)


if __name__ == "__main__":
    main()
